
module org.jbox2d {
    
    exports org.jbox2d.callbacks;
    exports org.jbox2d.gwtemul.org.jbox2d.common;
    exports org.jbox2d.common;
    exports org.jbox2d.dynamics;
    exports org.jbox2d.dynamics.joints;
    exports org.jbox2d.dynamics.contacts;
    exports org.jbox2d.pooling;
    exports org.jbox2d.pooling.normal;
    exports org.jbox2d.pooling.stacks;
    exports org.jbox2d.pooling.arrays;
    exports org.jbox2d.collision;
    exports org.jbox2d.collision.shapes;
    exports org.jbox2d.collision.broadphase;
    exports org.jbox2d.profile;
    
    opens org.jbox2d.callbacks;
    opens org.jbox2d.gwtemul.org.jbox2d.common;
    opens org.jbox2d.common;
    opens org.jbox2d.dynamics;
    opens org.jbox2d.dynamics.joints;
    opens org.jbox2d.dynamics.contacts;
    opens org.jbox2d.pooling;
    opens org.jbox2d.pooling.normal;
    opens org.jbox2d.pooling.stacks;
    opens org.jbox2d.pooling.arrays;
    opens org.jbox2d.collision;
    opens org.jbox2d.collision.shapes;
    opens org.jbox2d.collision.broadphase;
    opens org.jbox2d.profile;
}
